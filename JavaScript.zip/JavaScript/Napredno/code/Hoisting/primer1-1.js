x = 5;
console.log(x); // 5
var x;