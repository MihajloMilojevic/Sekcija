x = 5; // error 
console.log(x); // error
let x;