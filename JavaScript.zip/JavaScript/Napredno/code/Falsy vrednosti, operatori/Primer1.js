console.log(!!undefined);
console.log(!!false);
console.log(!!null);
console.log(!!0);
console.log(!!"");
console.log(!!NaN);
