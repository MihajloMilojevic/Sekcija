true || console.log("true || X");
false || console.log("false || X");
true && console.log("true && X");
false && console.log("false && X");
