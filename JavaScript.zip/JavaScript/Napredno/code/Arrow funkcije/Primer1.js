/* Razliciti nacini kreiranja arrow funkcija */
const nova = () => {}; //function () {}
const saParametrima = (a, b) => {return a + b;} //function (a, b) {return a + b;}
const direktnoVracanje = (a, b) => a + b; // function (a, b) {return a + b;}
const jedanParametar = x => x * x; // function (x) {return x * x;}