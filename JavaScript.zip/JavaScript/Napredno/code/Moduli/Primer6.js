import * as Primer1 from "./Primer1.js"
import * as Primer2 from "./Primer2.js"
import * as Primer3 from "./Primer3.js"
import * as Primer4 from "./Primer4.js"
import * as Primer5 from "./Primer5.js"

console.log(Primer1);
console.log(Primer2);
console.log(Primer3);
console.log(Primer4);
console.log(Primer5);