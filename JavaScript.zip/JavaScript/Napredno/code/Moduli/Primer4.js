console.log("Primer4");

const ucenik = {
	"ime": "Mihajlo",
	"prezime": "Milojevic",
	"mejl": "milojevicm374@gmail.com",
	"datumRodjenja": "31.05.2004."
}

export default ucenik;