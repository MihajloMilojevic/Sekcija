console.log("Primer5");

import ucenik from "./Primer4.js";

console.log(ucenik);