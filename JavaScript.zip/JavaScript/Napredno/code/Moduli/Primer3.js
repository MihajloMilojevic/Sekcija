console.log("Primer3");

import { add, multiply } from "./Primer2.js";

console.log(add(1, 2, 3));
console.log(multiply(1, 3, 5, 2));

