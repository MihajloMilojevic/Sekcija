let x = 5;
if(x % 2 === 0) {
    let poruka = "Broj je paran";
}
else {
    let poruka = "Broj je neparan";
}
console.log(poruka); // greška poruka nije definisana