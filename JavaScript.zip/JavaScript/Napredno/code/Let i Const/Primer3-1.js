const PI = 3.14;

PI = 3; // greška konstanti se ne može menjati vrednost