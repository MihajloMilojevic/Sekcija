class Tacka {
    x;
    y = 0;
    hello() {
        console.log("Hello World");
    }
}

const t1 = new Tacka();
t1.hello();