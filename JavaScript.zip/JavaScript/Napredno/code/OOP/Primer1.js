class Tacka { }

const t1 = new Tacka();