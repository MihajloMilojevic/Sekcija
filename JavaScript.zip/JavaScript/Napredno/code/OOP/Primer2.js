class Tacka {
    x;
    y = 0;
}

const t1 = new Tacka();
console.log(t1.x, t1.y);