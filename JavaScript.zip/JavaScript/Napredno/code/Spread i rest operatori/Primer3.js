const a = [2, 3, 4];
const b = [1, ...a, 5];
console.log(b);
// [ 1, 2, 3, 4, 5 ]