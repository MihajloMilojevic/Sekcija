const a = [1, 2, 3];
const b = [...a];
console.log(a === b);
// false