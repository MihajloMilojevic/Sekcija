document.getElementById("time").onclick = function() {
	console.log("###### CONSOLE.TIME #######");
    console.time();
}