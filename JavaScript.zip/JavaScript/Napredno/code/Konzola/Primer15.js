document.getElementById("timeEnd").onclick = function() {
	console.log("###### CONSOLE.TIMEEND #######");
    console.timeEnd();
}