document.getElementById("clear").onclick = function() {
	console.clear();
	console.log("Konzola obrisana");
}