document.getElementById("timeLog").onclick = function() {
	console.log("###### CONSOLE.TIMELOG #######");
    console.timeLog();
}