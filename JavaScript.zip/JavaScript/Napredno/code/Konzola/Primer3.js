document.getElementById("warn").onclick = function() {
	console.log("####### CONSOLE.WARN ########");
	console.warn("Upozorenje!!!");
	console.warn("Pazi ne smeš to uraditi");
}